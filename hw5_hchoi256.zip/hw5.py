import pandas as pd
import requests
import sys
import matplotlib.pyplot as plt
import numpy as np
from bs4 import BeautifulSoup

if __name__ == "__main__":
  # Question 1: Data Curation
  url = 'https://www.aos.wisc.edu/~sco/lakes/Mendota-ice.html'
  response = requests.get(url)
  html_soup = BeautifulSoup(response.text, 'html.parser')

  freeze = dict()
  # iterate through html tables
  for table in html_soup.find_all('table'):
      for tr in table.find_all('tr'):
          for count in [0, 5]:
              years = tr.find_all('td')[count].get_text(
                  separator='<br/>', strip=True).split('<br/>')
              days = tr.find_all(
                  'td')[count+3].get_text(separator='<br/>', strip=True).split('<br/>')
              length = len(years)
              for index in range(length):
                  if years[index] == "\"":
                      freeze[years[index-1].split('-')[0]] = days[index]
                  else:
                      freeze[years[index].split('-')[0]] = days[index]
  # remove first three elements
  freeze.pop("1852")
  freeze.pop("1853")
  freeze.pop("1854")
  freeze_dict = {
      'year': freeze.keys(),
      'days': freeze.values()
  }
  df = pd.DataFrame(freeze_dict)
  # save into .csv
  df.to_csv('hw5.csv', index=False)

  # Question 2: Visualize Data
  csvFile = sys.argv[1]
  data = pd.read_csv(csvFile)
  df = pd.DataFrame(data, columns=['year', 'days'])
  plt.plot(list(df['year']), list(df['days']))
  if len(df) >= 50:
      lst = []
      for i in range(int(len(df) / 10)):
        lst.append(df['year'][0]+10*i)
      plt.xticks(lst, rotation=45)
  else:
    plt.xticks(df['year'])
  # save as image
  plt.savefig("plot.jpg")

  # Question 3: Linear Regression
  # Q3a
  x = []
  for year in df['year']:
      x.append([1, year])
  X = np.array(x, dtype=np.int32)
  print("Q3a:")
  print(X)
  # Q3b
  y = []
  for day in df['days']:
      y.append(day)
  Y = np.array(y, dtype=np.int32)
  print("Q3b:")
  print(Y)
  # Q3c
  Z = np.matmul(np.transpose(X), X)
  print("Q3c:")
  print(Z)
  # Q3d
  I = np.linalg.pinv(Z)
  print("Q3d:")
  print(I)
  # Q3e
  PI = np.matmul(I, np.transpose(X))
  print("Q3e:")
  print(PI)
  # Q3f
  hat_beta = np.matmul(PI, Y)
  print("Q3f:")
  print(hat_beta)

  # Question 4: Prediction
  y_test = hat_beta[0] + hat_beta[1] * 2021
  print("Q4: " + str(y_test))

  # Question 5:Model Interpretation
  #sign = ""
  if hat_beta[1] < 0:
      sign = "<"
  elif hat_beta[1] > 0:
      sign = ">"
  else:
      sign = "="
  print("Q5a: " + sign)
  print("Q5b: " + "hat_beta[1] represents the trend slope for Mendota freeze days. A positive sign means that the Mendota freeze time is likely to increase, otherwise negative means the time is likely to decrease, otherwise, it is likely to remain the same.")

  # Question 6: Model Limitation
  xstar = (0 - hat_beta[0]) / hat_beta[1]
  print("Q6a: " + str(xstar))
  print("Q6b: " + "Since the plot shows that the trend is decreasing (we found the slope was negative) and the y_test value for 2021 ​​is very low, we can assume that x* is a strong prediction.")
